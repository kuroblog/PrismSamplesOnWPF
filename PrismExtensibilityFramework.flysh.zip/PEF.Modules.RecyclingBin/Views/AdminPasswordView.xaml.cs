﻿
namespace PEF.Modules.RecyclingBin.Views
{
    using System.Windows.Controls;

    public partial class AdminPasswordView : UserControl
    {
        public AdminPasswordView()
        {
            InitializeComponent();
        }
    }
}
