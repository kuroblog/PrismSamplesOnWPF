﻿
namespace PEF.Modules.RecyclingBin.Views
{
    using System.Windows.Controls;

    public partial class RecycleView : UserControl
    {
        public RecycleView()
        {
            InitializeComponent();
        }
    }
}
