﻿
namespace PEF.Modules.RecyclingBin.Views
{
    using System.Windows.Controls;

    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}
