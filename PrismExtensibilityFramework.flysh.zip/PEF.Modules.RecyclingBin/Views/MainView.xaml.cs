﻿
namespace PEF.Modules.RecyclingBin.Views
{
    using System.Windows.Controls;

    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
