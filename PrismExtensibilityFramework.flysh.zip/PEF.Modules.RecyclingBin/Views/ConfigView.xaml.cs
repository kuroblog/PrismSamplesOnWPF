﻿
namespace PEF.Modules.RecyclingBin.Views
{
    using System.Windows.Controls;

    public partial class ConfigView : UserControl
    {
        public ConfigView()
        {
            InitializeComponent();
        }
    }
}
