﻿
namespace PEF.Logger
{
    using System;

    [Serializable]
    public class RetryException : Exception { }
}
