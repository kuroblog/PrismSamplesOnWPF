﻿
namespace PEF.Common.Controls
{
    using System.Windows.Controls;

    public partial class CustomMessagePopupWindow : UserControl
    {
        public CustomMessagePopupWindow()
        {
            InitializeComponent();
        }
    }
}
