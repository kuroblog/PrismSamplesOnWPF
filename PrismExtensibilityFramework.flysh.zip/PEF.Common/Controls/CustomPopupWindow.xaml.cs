﻿
namespace PEF.Common.Controls
{
    using System.Windows.Controls;

    public partial class CustomPopupWindow : UserControl
    {
        public CustomPopupWindow()
        {
            InitializeComponent();
        }
    }
}
