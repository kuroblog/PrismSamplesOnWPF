﻿
namespace PEF.Common
{
    /// <summary>
    /// 统一定义窗体间跳转时，要传递的参数的 Key
    /// </summary>
    public class NavigationKeys { }
}
