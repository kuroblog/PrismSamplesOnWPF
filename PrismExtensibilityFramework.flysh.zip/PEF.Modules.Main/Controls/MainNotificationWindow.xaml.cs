﻿
namespace PEF.Modules.Main.Controls
{
    using System.Windows.Controls;

    public partial class MainNotificationWindow : UserControl
    {
        public MainNotificationWindow()
        {
            InitializeComponent();
        }
    }
}
