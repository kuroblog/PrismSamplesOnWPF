﻿
namespace PEF.Modules.AuthTerminal.Views
{
    using System.Windows.Controls;

    public partial class ScanView : UserControl
    {
        public ScanView()
        {
            InitializeComponent();
        }
    }
}
