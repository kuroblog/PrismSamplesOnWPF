﻿
namespace PEF.Modules.SGDE.Views
{
    using System.Windows.Controls;

    public partial class DistributeResultView : UserControl
    {
        public DistributeResultView()
        {
            InitializeComponent();
        }
    }
}
