﻿
namespace PEF.Modules.SGDE.Views
{
    using System.Windows.Controls;

    public partial class SizeConfigView : UserControl
    {
        public SizeConfigView()
        {
            InitializeComponent();
        }
    }
}
