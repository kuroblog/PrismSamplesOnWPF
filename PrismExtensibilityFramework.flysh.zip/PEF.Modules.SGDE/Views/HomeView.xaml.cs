﻿
namespace PEF.Modules.SGDE.Views
{
    using System.Windows.Controls;

    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }
    }
}
