﻿
namespace PEF.Modules.SGDE.Views
{
    using System.Windows.Controls;

    public partial class SizeChoiceView : UserControl
    {
        public SizeChoiceView()
        {
            InitializeComponent();
        }
    }
}
