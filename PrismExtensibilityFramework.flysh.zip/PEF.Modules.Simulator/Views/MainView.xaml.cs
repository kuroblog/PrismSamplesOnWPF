﻿
namespace PEF.Modules.Simulator.Views
{
    using System.Windows.Controls;

    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
