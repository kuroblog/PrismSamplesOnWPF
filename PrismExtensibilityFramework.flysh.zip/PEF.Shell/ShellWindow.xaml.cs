﻿
namespace PEF.Shell
{
    using System.Windows;

    public partial class ShellWindow : Window
    {
        public ShellWindow()
        {
            InitializeComponent();
        }
    }
}
