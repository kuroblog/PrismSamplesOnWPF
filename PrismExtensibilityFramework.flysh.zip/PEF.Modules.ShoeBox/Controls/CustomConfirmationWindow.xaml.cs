﻿
namespace PEF.Modules.ShoeBox.Controls
{
    using System.Windows.Controls;

    public partial class CustomConfirmationWindow : UserControl
    {
        public CustomConfirmationWindow()
        {
            InitializeComponent();
        }
    }
}
