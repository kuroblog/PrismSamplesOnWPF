﻿
namespace PEF.Modules.ShoeBox.Controls
{
    using System.Windows.Controls;

    public partial class CustomNotificationWindow : UserControl
    {
        public CustomNotificationWindow()
        {
            InitializeComponent();
        }
    }
}
