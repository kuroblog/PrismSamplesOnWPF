﻿
namespace PEF.Modules.ShoeBox.Views
{
    using System.Windows.Controls;

    public partial class ConfigView : UserControl
    {
        public ConfigView()
        {
            InitializeComponent();
        }
    }
}
