﻿
namespace PEF.Modules.ShoeBox.Views
{
    using System.Windows.Controls;

    public partial class ResultView : UserControl
    {
        public ResultView()
        {
            InitializeComponent();
        }

        //private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    var vm = DataContext as ViewModels.ResultViewModel;
        //    vm.ConfirmStatus = !vm.ConfirmStatus;

        //    //vm.CloseDoorHandler("");
        //}
    }
}
