﻿
namespace PEF.Modules.ShoeBox.Views
{
    using System.Windows.Controls;

    public partial class AdminPasswordView : UserControl
    {
        public AdminPasswordView()
        {
            InitializeComponent();
        }
    }
}
